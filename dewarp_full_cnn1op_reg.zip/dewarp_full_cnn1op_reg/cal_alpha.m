function [alphaR, alphaC] = cal_alpha(imR, imC, cntr, cm_d, a, p, dpth, thta, y_arc)
betaR = zeros(imR, imC);
betaC = zeros(imR, imC);
c_r = round(imR*cntr(1));
c_c = round(imC*cntr(2));
d1 = dpth(c_r,c_c);
R_dist = zeros(imR, imC);
for i = 1:imC
%     R_dist(:,i) = abs((1:imR)-c_r);
    R_dist(:,i) = c_r-(1:imR);
end
C_dist = zeros(imR, imC);
for i = 1:imR
%     C_dist(i,:) = abs((1:imC)-c_c);
    C_dist(i,:) = c_c-(1:imC);
end

E_dist = zeros(imR, imC);
E_dist = sqrt(R_dist.^2 + C_dist.^2);
% E_dist = E_dist/cm_d;
beta = atand(E_dist/cm_d);
betaR = atand(R_dist/cm_d);
betaC = atand(C_dist/cm_d);
C1 = (a./p).*sind(thta) - cotd(thta);
% alphaR = acotd(((a.*cotd(betaR)+dpth).*(p.*sind(thta)))./(a.*p.*sind(thta)-(dpth-d1).*(a-p.*cosd(thta))));

x = 1:imC;
y1 = x-y_arc'; %%EG

a1 = zeros(imR,imC);
for i = 1:imR
    a1(i,:) = (a(i,:)- y1);
end
% % alphaR = atand(a1./(a.*cotd(betaR) + dpth));
% % alphaC = atand(a1./(a.*cotd(betaC) + dpth));
% % for i = 1800:1920
% %     alphaR(:,i) = (alphaR(:,1799) + alphaR(:,1921))/2;
% % end

% alphaR = atand(a1./(cm_d + dpth));
% alphaC = atand(a1./(cm_d + dpth));

% alphaC = acotd(((a.*cotd(betaC)+dpth).*(p.*sind(thta)))./(a.*p.*sind(thta)-(dpth-d1).*(a-p.*cosd(thta))));
% for i = 1:imR
%     for j = 1:imC
%         isnan(alphaR(i,j))
%         
%         
%     end
% end



pst = dpth-d1;
pct = a1;
T1 = a/cm_d - (pct./(cm_d+d1+pst));
T2 = a/cm_d.*(pct./(cm_d+d1+pst)) + 1;
T = atand(T1./T2);
alphaR = betaR - T;
alphaC = betaC - T;
alphaR(isnan(alphaR)) = 0;
alphaC(isnan(alphaC)) = 0;
end

