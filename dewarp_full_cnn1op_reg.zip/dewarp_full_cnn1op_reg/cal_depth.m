function [dpth, theta] = cal_depth(imR, imC, P3,P7,P6,P10, P1, P2)
dpth = zeros(imR,imC);
theta = zeros(imR,imC);
div_fac = 0.5;
P4 = P3*div_fac;
P8 = P7*div_fac;
P5 = P6*div_fac;
P9 = P10*div_fac;

%% Specify First knot values
fac_y = [P3 (P3+P7)/2 P7];
fac_x = [1 imR*0.5 imR];
[fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
fac_x1 = 1:imR;
knot1 = feval(fitresult, fac_x1);


%% Specify 2nd knot values
fac_y = [P4 (P4+P8)/2 P8];
fac_x = [1 imR*0.5 imR];
[fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
fac_x1 = 1:imR;
knot2 = feval(fitresult, fac_x1);

%% Specify fourth knot values
fac_y = [P5 (P5+P9)/2 P9];
fac_x = [1 imR*0.5 imR];
[fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
fac_x1 = 1:imR;
knot4 = feval(fitresult, fac_x1);


%% Specify fifth knot values
fac_y = [P6 (P6 + P10)/2 P10];
fac_x = [1 imR*0.5 imR];
[fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
fac_x1 = 1:imR;
knot5 = feval(fitresult, fac_x1); 

%% Specify the parameters in the entire document
% max_pt = 0.5;
brk_y = [P1 (P1+P2)/2 P2];
brk_x = [1 imR*0.5 imR];
P = polyfit(brk_x,brk_y,1);
brk_x1 = 1:imR;
max_pt = P(1)*brk_x1+P(2);
%% same size
x = 1:imC;
i = 1;
% for i = 1:imR
    mf = imC*max_pt(i);
%     x1 = [1 imC*(max_pt(i)*0.5) imC*(max_pt(i)*0.75) imC*max_pt(i) imC*(1-(1-max_pt(i))*0.75) imC*(1-(1-max_pt(i))*0.5) imC];
    x1 = [1 mf*0.5 mf mf+((imC - mf)*0.5) imC];
%     y1 = [fac_l(i) fac_l(i)/2 fac_l(i)/4 0 fac_l(i)/4 fac_l(i)/2 fac_r(i)];
    y1 = [knot1(i) knot2(i) 0  knot4(i) knot5(i)];
    [fitresult, gof] = createFit(x1, y1, 0.1,50);
    y = feval(fitresult,x);
%     y = spline(x1,y1,x);
%     figure, plot(x1, y1, 'o', x, y);
    for j = 1:imR
        dpth(j,1:imC) = y;
    end
    x1th = [1 mf*0.5 mf mf+((imC - mf)*0.5) imC];
    y1th = [atand(knot1(i)/mf) atand(knot2(i)/(mf/2)) 0 atand(knot4(i)/(mf+((imC - mf)*0.5))) atand(knot5(i)/imC)];
    [fitresult, gof] = createFit(x1th, y1th, 0.1,50);
    y = feval(fitresult,x);
    for j = 1:imR
        theta(j,1:imC) = y;
    end
    
% end

%% 2D array
% % % % x = 1:imC;
% % % % for i = 1:imR
% % % %     mf = imC*max_pt(i);
% % % % %     x1 = [1 imC*(max_pt(i)*0.5) imC*(max_pt(i)*0.75) imC*max_pt(i) imC*(1-(1-max_pt(i))*0.75) imC*(1-(1-max_pt(i))*0.5) imC];
% % % %     x1 = [1 mf*0.5 mf mf+((imC - mf)*0.5) imC];
% % % % %     y1 = [fac_l(i) fac_l(i)/2 fac_l(i)/4 0 fac_l(i)/4 fac_l(i)/2 fac_r(i)];
% % % %     y1 = [fac_l(i) fac_l(i)/2 0  fac_r(i)/2 fac_r(i)];
% % % %     [fitresult, gof] = createFit(x1, y1, 0.1,50);
% % % %     y = feval(fitresult,x);
% % % % %     y = spline(x1,y1,x);
% % % % %     figure, plot(x1, y1, 'o', x, y);
% % % %     dpth(i,:) = y;
% % % %     
% % % %     x1th = [1 mf*0.5 mf mf+((imC - mf)*0.5) imC];
% % % %     y1th = [atand(fac_l(i)/mf) atand((fac_l(i)/2)/(mf/2)) 0 atand((fac_r(i)/2)/(mf+((imC - mf)*0.5))) atand(fac_r(i)/imC)];
% % % %     [fitresult, gof] = createFit(x1th, y1th, 0.1,50);
% % % %     y = feval(fitresult,x);
% % % %     theta(i,:) = y;
% % % % end
% % % % 
% % % %  

%% Convert into 1D array
% % %     mf = imC.*max_pt';
% % %     imC_m = zeros(imR,1);
% % %     imC_m = imC_m + imC;
% % % %     x1 = [1 imC*(max_pt(i)*0.5) imC*(max_pt(i)*0.75) imC*max_pt(i) imC*(1-(1-max_pt(i))*0.75) imC*(1-(1-max_pt(i))*0.5) imC];
% % %     x1 = [ones(imR,1) mf*0.5 mf mf+((imC - mf)*0.5) imC_m];
% % % %     y1 = [fac_l(i) fac_l(i)/2 fac_l(i)/4 0 fac_l(i)/4 fac_l(i)/2 fac_r(i)];
% % %     y1 = [fac_l fac_l/2 zeros(imR,1)  fac_r/2 fac_r];
% % %     for i = 1:imR
% % %        x1(i,:) = x1(i,:) + (i-1)*imC; 
% % %     end
% % %     x1p = x1';
% % %     x1d = x1p(:);
% % %     y1p = y1';
% % %     y1d = y1p(:);
% % % %     [fitresult, gof] = createFit(x1d, y1d, 0.1,5);
% % %     [fitresult, gof] = createFit(x1d, y1d, 0.00023,1);
% % %     y = feval(fitresult,1:imR*imC);
% % %     yr = reshape(y,imC,imR);
% % %     yr = yr';
% % % %     y = spline(x1,y1,x);
% % % %     figure, plot(x1, y1, 'o', x, y);
% % %     dpth = yr;
% % %     
% % %     
% % %     x1th = [ones(imR,1) mf*0.5 mf mf+((imC - mf)*0.5) imC_m];
% % %     y1th = [atand(fac_l./mf) atand((fac_l/2)./(mf/2)) zeros(imR,1) atand((fac_r/2)./(mf+((imC - mf)*0.5))) atand(fac_r./imC)];
% % %    
% % %     y1pth = y1th';
% % %     y1dth = y1pth(:);
% % % %     [fitresult, gof] = createFit(x1d, y1d, 0.1,5);
% % %     [fitresult, gof] = createFit(x1d, y1dth, 0.00023,1);
% % %     yth = feval(fitresult,1:imR*imC);
% % %     yrth = reshape(yth,imC,imR);
% % %     yrth = yrth';
% % %     theta = yrth;
% % % % bs = 10;
% % % % for i = -bs:0
% % % % theta(:,round(imC*max_pt)+i) = theta(:,round(imC*max_pt)-bs-1);
% % % % end
% % % % for i = 1:bs
% % % % theta(:,round(imC*max_pt)+i) = theta(:,round(imC*max_pt)+bs+1);
% % % % end

end

