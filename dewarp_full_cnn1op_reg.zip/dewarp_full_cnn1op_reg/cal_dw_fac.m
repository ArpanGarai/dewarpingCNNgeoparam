function [ dw_A ] = cal_dw_fac(imR, imC,w_fac_t_l,w_fac_b_l,w_fac_t_r,w_fac_b_r, brk_t, brk_b )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
dw_A = zeros(imR, imC);

%% Specify the parameters at 'left' side of the Document Image 
fac_y = [w_fac_t_l (w_fac_t_l+w_fac_b_l)/2 w_fac_b_l];
fac_x = [1 imR*0.5 imR];
[fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
fac_x1 = 1:imR;
fac_l = feval(fitresult, fac_x1); 
%% Specify the parameters at 'right' side of the Document Image
fac_y = [w_fac_t_r (w_fac_t_r+w_fac_b_r)/2 w_fac_b_r];
fac_x = [1 imR*0.5 imR];
[fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
fac_x1 = 1:imR;
fac_r = feval(fitresult, fac_x1); 

%% Specify the parameters in the entire document
% max_pt = 0.5;
brk_y = [brk_t (brk_t+brk_b)/2 brk_b];
brk_x = [1 imR*0.5 imR];
P = polyfit(brk_x,brk_y,1);
brk_x1 = 1:imR;
max_pt = P(1)*brk_x1+P(2);

x = 1:imC;
for i = 1:imR
%     x1 = [1 imC*(max_pt(i)*0.5) imC*(max_pt(i)*0.75) imC*max_pt(i) imC*(1-(1-max_pt(i))*0.75) imC*(1-(1-max_pt(i))*0.5) imC];
    x1 = [1 imC*(max_pt(i)*0.5) imC*max_pt(i) imC*(1-(1-max_pt(i))*0.5) imC];
%     y1 = [fac_l(i) fac_l(i)/2 fac_l(i)/4 0 fac_l(i)/4 fac_l(i)/2 fac_r(i)];
    y1 = [fac_l(i) fac_l(i)/2 0  fac_l(i)/2 fac_r(i)];
    [fitresult, gof] = createFit(x1, y1, 0.1,50);
    y = feval(fitresult,x);
%     y = spline(x1,y1,x);
%     figure, plot(x1, y1, 'o', x, y);
    dw_A(i,:) = y;
end

end

