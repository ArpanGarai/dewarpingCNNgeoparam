function [ rot_A ] = cal_rot_fac(imR, imC)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
rot_A = zeros(imR, imC);
rot_A(:,:) = tand(0);
end

