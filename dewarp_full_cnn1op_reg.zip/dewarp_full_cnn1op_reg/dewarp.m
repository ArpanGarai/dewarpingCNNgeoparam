function [dw_A, ds_r, ds_c] = dewarp(op_A, d_r, d_c)

[imR, imC] = size(op_A);
[rd, cd] = size(d_r);
ds_r = zeros(imR, imC, class(d_r));
ds_c = zeros(imR, imC, class(d_c));
dw_A = zeros(imR, imC, class(op_A));
top_sft = min(d_r(1,:));
if top_sft > 0
    top_sft = 0;
end
top_sft = abs(top_sft);
for i = 1:min(rd,imR)
    for j = 1:min(cd,imC)
         if op_A(i,j) == 1
%             i1 = max(1,floor(i+d_r(i,j)+top_sft));
%             j1 = max(1,floor(j+d_c(i,j)));
            
%             %         j1 = max(1,floor(j+i*rot_A(i,j)));
%             ds_r(i1,j1)= -d_r(i,j);
%             ds_c(i1,j1)= -d_c(i,j);
            i1 = max(1,(i-d_r(i,j)+top_sft));
            j1 = max(1,(j-d_c(i,j)));
            ds_r(i,j)= round(i1);
            ds_c(i,j)= round(j1);
            dw_A(ceil(i1), ceil(j1)) = op_A(i,j);
            dw_A(floor(i1), floor(j1)) = op_A(i,j);
%             i1 = max(1,ceil(i+d_r(i,j)+top_sft));
%             j1 = max(1,ceil(j+d_c(i,j)));


%             %         j1 = max(1,ceil(j+i*rot_A(i,j)));
%             ds_r(i1,j1)= -d_r(i,j);
%             ds_c(i1,j1)= -d_c(i,j);
            

         end
    end
end

%    dw_A = warp(op_A, ds_r, ds_c);





