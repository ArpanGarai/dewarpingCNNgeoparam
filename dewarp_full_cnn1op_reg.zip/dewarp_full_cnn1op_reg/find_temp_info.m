function [OP_tmpr,OP_tmpc] = find_temp_info(OP)
[opr, opc] = size(OP);
OP_tmpr = zeros(size(OP));
OP_tmpc = zeros(size(OP));
for i = 1:opr
    OP_tmpc(i,:) = 1:opc;
end
for i = 1:opc
    OP_tmpr(:,i) = 1:opr;
end

cc = bwconncomp(OP);
cpr = regionprops(cc,'all');
% cpr = regionprops(cc);

if cc.NumObjects > 0
    for k = 1:cc.NumObjects
        for j = 1:cpr(k).BoundingBox(3)
%             cpr(k).BoundingBox(1):cpr(k).BoundingBox(1)+cpr(k).BoundingBox(3)
            flg = 0;
            for i = 1:cpr(k).BoundingBox(4)
%                 cpr(k).BoundingBox(2):cpr(k).BoundingBox(2)+cpr(k).BoundingBox(4)
                if cpr(k).Image(i,j)
                    if flg == 0
                        flg = 1;
                        ofst = i;
                        OP_tmpr(round(cpr(k).BoundingBox(2))+i,round(cpr(k).BoundingBox(1))+j) = round(cpr(k).BoundingBox(2)) + i - ofst;
                    else
                        OP_tmpr(round(cpr(k).BoundingBox(2))+i,round(cpr(k).BoundingBox(1))+j) = round(cpr(k).BoundingBox(2)) + i - ofst;
                    end
                end
            end
        end
    end
end

end

