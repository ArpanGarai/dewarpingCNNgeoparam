function [ wr_fac ] = gen_warp_fac( imR, imC, w_fac_t_l, w_fac_b_l, w_fac_t_r, w_fac_b_r , rot_A, brk_t, brk_b)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
wr_fac = zeros(imR,imC);
dw_A = cal_dw_fac(imR, imC,w_fac_t_l,w_fac_b_l,w_fac_t_r,w_fac_b_r, brk_t, brk_b);
j = 1:imC;
rot_bayas = max(j.*rot_A(1,j));
for i = 1:imR
    for j = 1:imC
        i1 = max(1,floor(i+dw_A(i,j)-j*rot_A(i,j)+rot_bayas));
        j1 = max(1,floor(j+i*rot_A(i,j)));
        wr_fac(i1,j1)= -dw_A(i,j);
        i1 = max(1,ceil(i+dw_A(i,j)-j*rot_A(i,j)+rot_bayas));
        j1 = max(1,ceil(j+i*rot_A(i,j)));
        wr_fac(i1,j1)= -dw_A(i,j);
    end
end
end

