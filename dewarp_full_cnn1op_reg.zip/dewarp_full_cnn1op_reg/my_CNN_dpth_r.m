function [net, accuracy] = my_CNN_dpth_r(imds, numTrainFiles,ipr, ipc, no_op, no_epoch,chk_pth)
tym = 2;
labelCount = countEachLabel(imds);
[imdsTrain,imdsValidation] = splitEachLabel(imds,numTrainFiles,'randomize');
layers = [
    imageInputLayer([ipr ipc 1])
    
    convolution2dLayer(9,8,'Padding',4)
    batchNormalizationLayer
    reluLayer
    convolution2dLayer(5,32,'Padding',2)
    batchNormalizationLayer
    reluLayer
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
%     maxPooling2dLayer(2,'Stride',2)
    maxPooling2dLayer(2,'Stride',2) %r/2
    
    
    convolution2dLayer(5,64,'Padding',2)
    batchNormalizationLayer
    reluLayer
    convolution2dLayer(5,64,'Padding',2)
    batchNormalizationLayer
    reluLayer
    convolution2dLayer(3,64,'Padding',2)
    batchNormalizationLayer
    reluLayer
    convolution2dLayer(3,64,'Padding',2)
    batchNormalizationLayer
    reluLayer
    
%     maxPooling2dLayer(2,'Stride',2)
    maxPooling2dLayer(2,'Stride',2) %r/4
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(5,128,'Padding',2)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,128,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer

    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer

    maxPooling2dLayer(2,'Stride',2) %r/8
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer

    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,64,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,32,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    convolution2dLayer(3,16,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    
    convolution2dLayer(3,9,'Padding',1)
    batchNormalizationLayer
    reluLayer
    
    fullyConnectedLayer(no_op)
    regressionLayer];

if tym > 1    
    latestfile = getlatestfile(chk_pth);
    load([chk_pth latestfile],'net');
end
options = trainingOptions('sgdm', ...
    'CheckpointPath',chk_pth, ...
    'Momentum',0.95, ... 
    'MaxEpochs',no_epoch, ...
    'ValidationData',imdsValidation, ...
    'MiniBatchSize',16, ...
    'ValidationFrequency',50, ...
    'Verbose',false, ...
    'InitialLearnRate',0.0001, ...
    'Plots','training-progress');
if tym == 1
     net = trainNetwork(imdsTrain,layers,options);
else
    net = trainNetwork(imdsTrain,net,options);
end
YPredicted = predict(net,XValidation);
predictionError = YValidation - YPredicted;
thr = 0.1;
numCorrect = sum(abs(predictionError) < thr);
numValidationImages = numel(YValidation);

accuracy = numCorrect/numValidationImages
squares = predictionError.^2;
rmse = sqrt(mean(squares))

%YPred = classify(net,imdsValidation);
%YValidation = imdsValidation.Labels;

%accuracy = sum(YPred == YValidation)/numel(YValidation);

end

