clear all;
close all;
linux = 1;
%% Load previous the network and data
if linux == 0
    load(['C:\Users\CST\Documents\PhD\Matlab_code\dewarping_fullycnn\Env\' 'network_values.mat']);
else
    load(['/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/' 'network_values_all.mat']);
end




ippath_bnry = '/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/syn_img_org/B001/';

op_pth_im = '/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/op1op/B001/';






%for i = 1:486
% ipflnm = ['B001_GT_Text_only_' int2str(i) '.png'];


%ipflnm = ['GT_B001_' int2str(i) '.tiff'];
ipflnm = 'B005.jpg';

%opflnm = ['OP_B001_' int2str(i) '.tiff'];
opflnm = ['OP_' 'B005.jpg'];

A = imread([ippath_bnry ipflnm]);
[r,c,d] = size(A);


if d>1
Abin = rgb2gray(A);
Abin = imbinarize(Abin,'adaptive','ForegroundPolarity','dark','Sensitivity',0.45);
end

if r <c
    Abin = imrotate(Abin,90);
end
%se = strel('line',sqrt(r^2+c^2)/35,3);

%Abind = ~imdilate(~Abin,se);
Abind = imread('B005seg_lines.png');
[r1,c1,d1] = size(Abind);
if d1>1
Abind = rgb2gray(Abind);
Abind = imbinarize(Abind,'adaptive','ForegroundPolarity','dark','Sensitivity',0.45);
end


if r <c
    Abind = imrotate(Abind,-90);
end

if r>c
    fac = 120/r;
else
    fac = 120/c;
end
Abind_s = imresize(Abind,fac,'bicubic');
[or, oc] = size(Abind_s);
R = ipr;
I = zeros(ipr,ipc);
%%
% 
% $$e^{\pi i} + 1 = 0$$
% 


difr=floor((R-or)/2);
difc=floor((R-oc)/2);
I(difr+1:or+difr,difc+1:oc+difc) = ~Abind_s;
[OP_tmpr,C_c] = find_temp_info(I);
I = ~I;
%% The processing


%Y_hmp = classify(net_hmp,uint8(I));
%Y_dpth = classify(net_dpth,uint8(I));
%Y_cam_angl = classify(net_cam_angl,uint8(I));
%Y_cam_cntr = classify(net_cam_cntr,uint8(I));

Y_hmp = predict(net_hmp,uint8(I));
Y_dpth_l = predict(net_dpth_l,uint8(I));
Y_dpth_r = predict(net_dpth_r,uint8(I));
Y_cam_angl = predict(net_cam_angl,uint8(I));
Y_cam_cntr = predict(net_cam_cntr,uint8(I));




%% Getting the values of the parameters
brk_t = Y_hmp/10;
brk_b = brk_t;

w_fac_t_l = Y_dpth_l;
w_fac_b_l = Y_dpth_l;
w_fac_t_r = Y_dpth_r;
w_fac_b_r = Y_dpth_r;
cntr = [Y_cam_cntr, 0.5];
cm_angle = Y_cam_angl;


%cm_angle = double(Y_cam_angl) - 3;
%cntr = cal_cntr_4m_cls(Y_cam_cntr);
%[w_fac_t_l, w_fac_b_l, w_fac_t_r, w_fac_b_r] = cal_dpth_4m_cls(r,c,Y_cam_cntr);


cm_d = c;
[depth, theta] = cal_depth(r, c, w_fac_t_l, w_fac_b_l, w_fac_t_r, w_fac_b_r, brk_t, brk_b);
depth = add_angle(depth,cm_angle,cntr);
[arc_ln, y_arc, a, p, thta] = arc_len(r, c, depth, cntr);
[alphaR, alphaC] = cal_alpha(r, c, cntr, cm_d, a, p, depth, thta, y_arc);

[d_r, d_c] = cal_wf(r, c,depth, alphaR, alphaC);
op_A = ~dewarp(~Abin,d_r,d_c);
op_A_rgb = dewarp_rgb(A,d_r,d_c);
imwrite(op_A,[op_pth_im opflnm]);

imwrite(op_A_rgb,[op_pth_im 'rgb_' opflnm]);



% figure, imshow(op_A);
% figure, imshow(Abin);
%end
