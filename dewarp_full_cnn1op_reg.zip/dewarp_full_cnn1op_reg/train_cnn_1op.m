%% Deep Neural Network
clear all;
close all;
lnx = 1;
if lnx == 0
%     imds_brk_t = imageDatastore('C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\brk_t\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_brk_b = imageDatastore('C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\brk_b\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_w_fac_b_l = imageDatastore('C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_b_l\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_w_fac_b_r = imageDatastore('C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_b_r\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_w_fac_t_r = imageDatastore('C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_t_r\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
    imds_w_fac_t_l = imageDatastore('C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_t_l\','FileExtensions',{'.tiff'},'IncludeSubfolders',true,'LabelSource','foldernames');
else
%     imds_brk_t = imageDatastore('C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\brk_t\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_brk_b = imageDatastore('C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\brk_b\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_w_fac_b_l = imageDatastore('C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_b_l\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_w_fac_b_r = imageDatastore('C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_b_r\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
%     imds_w_fac_t_r = imageDatastore('C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_t_r\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
imds_hmp = imageDatastore('/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_1op/hump/','FileExtensions',{'.tiff'},'IncludeSubfolders',true,'LabelSource','foldernames');
imds_cam_cntr = imageDatastore('/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_1op/cam_cntr/','FileExtensions',{'.tiff'},'IncludeSubfolders',true,'LabelSource','foldernames');
imds_cam_angl = imageDatastore('/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_1op/cam_angl/','FileExtensions',{'.tiff'},'IncludeSubfolders',true,'LabelSource','foldernames');
imds_dpth_l = imageDatastore('/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_1op/dpth_l/','FileExtensions',{'.tiff'},'IncludeSubfolders',true,'LabelSource','foldernames');
imds_dpth_r = imageDatastore('/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_1op/dpth_r/','FileExtensions',{'.tiff'},'IncludeSubfolders',true,'LabelSource','foldernames');
% imds_w_fac_t_l = imageDatastore('C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\small\w_fac_t_l\','FileExtensions',{'.png'},'IncludeSubfolders',true,'LabelSource','foldernames');
end
% labelCount = countEachLabel(imds);

% ipr = 256;
% ipc = 150;
% no_op = 6;
% no_epoch = 50;
% net_brk_t = my_CNN(imds_brk_t, numTrainFiles,ipr, ipc, no_op, no_epoch);
% net_brk_b = my_CNN(imds_brk_b, numTrainFiles,ipr, ipc, no_op, no_epoch);


ipr = 125;
ipc = 125;
if lnx == 0
    chk_pth = 'C:\Users\CST\Documents\PhD\Matlab_code\CNN_unwarp\Env\';
else
    chk_pth_hmp = '/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/hmp/checkpoints/';
    chk_pth_dpth_l = '/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/dpth_l/checkpoints/';
    chk_pth_dpth_r = '/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/dpth_r/checkpoints/';
    chk_pth_cam_cntr = '/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/cam_cntr/checkpoints/';
    chk_pth_cam_angl = '/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/cam_angl/checkpoints/';
end
no_op = 2;
no_epoch = 2;
numTrainFiles = 1800;
[net_hmp, accuracy_hmp] = my_CNN_hmp(imds_hmp, numTrainFiles, ipr, ipc, no_op, no_epoch,chk_pth_hmp);
no_op = 9;
no_epoch = 40;
numTrainFiles = 400;
[net_dpth_l, accuracy_dpth_l] = my_CNN_dpth_l(imds_dpth_l, numTrainFiles, ipr, ipc, no_op, no_epoch,chk_pth_dpth_l);
[net_dpth_r, accuracy_dpth_r] = my_CNN_dpth_r(imds_dpth_r, numTrainFiles, ipr, ipc, no_op, no_epoch,chk_pth_dpth_r);
[net_cam_cntr, accuracy_cam_cntr] = my_CNN_cam_cntr(imds_cam_cntr, numTrainFiles, ipr, ipc, no_op, no_epoch,chk_pth_cam_cntr);
no_op = 3;
numTrainFiles = 1100;
no_epoch = 10;
[net_cam_angl, accuracy_cam_angl] = my_CNN_cam_angl(imds_cam_angl, numTrainFiles, ipr, ipc, no_op, no_epoch,chk_pth_cam_angl);
if lnx == 0
    save(['C:\Users\CST\Documents\PhD\Matlab_code\CNN_unwarp\Env\' 'network_values.mat']);
else
    save(['/home/arpan/Documents/PhD/Matlab_code/dewarp_full_cnn1op/Env/' 'network_values.mat']);
end
