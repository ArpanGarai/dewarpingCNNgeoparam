function [op_A] = warp(Ab,d_r,d_c)
[imR, imC] = size(Ab);
op_A = zeros(imR, imC,class(Ab));
% op_A = imcomplement(op_A);
% j = 1:imC;
% rot_bayas_i = max(j.*rot_A(1,j));
top_sft = min(d_r(1,:));
if top_sft > 0
    top_sft = 0;
end
top_sft = abs(top_sft);
for i = 1:imR
    for j = 1:imC
          if Ab(i,j) == 1
            i1 = max(1,floor(i+d_r(i,j)+top_sft));
            j1 = max(1,floor(j+d_c(i,j)));
            %         j1 = max(1,floor(j+i*rot_A(i,j)));
            op_A(i1,j1)= Ab(i,j);
%             i1 = max(1,ceil(i+d_r(i,j)+top_sft));
            j1 = max(1,ceil(j+d_c(i,j)));
            %         j1 = max(1,ceil(j+i*rot_A(i,j)));
            op_A(i1,j1)= Ab(i,j);
         end
    end
end


end

